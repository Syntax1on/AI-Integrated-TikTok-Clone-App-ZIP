# 🎵 TikTok AI Clone App

A basic TikTok-style app backend with an AI-powered caption generator. Users can submit descriptions of their videos, and the AI will generate a viral caption and hashtags.

## 🧠 Features
- AI-generated TikTok captions
- Flask-based backend
- OpenAI GPT-powered

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your API key
```bash
export OPENAI_API_KEY="your-api-key"
```

### 3. Run the server
```bash
python app.py
```

### 4. Example POST request
```bash
curl -X POST http://localhost:5000/caption -H "Content-Type: application/json" -d '{"video_description": "A dog dancing to hip-hop music"}'
```

## 🔧 Stack
- Flask
- OpenAI GPT-3.5

---

MIT License © 2025 XaydenTech